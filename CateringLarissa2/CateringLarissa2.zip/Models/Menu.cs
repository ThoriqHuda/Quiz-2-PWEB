﻿namespace CateringLarissa2.Models
{
    public class Menu
    {
        public int id { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public int price { get; set; }

        public string menuimage { get; set; }

        public Menu()
        {

        }
    }
}
