﻿namespace CateringLarissa2.ViewModels
{
    public class MenuViewModel
    {
        public string title { get; set; }
        public string description { get; set; }
        public int price { get; set; }
        public IFormFile menuimage  { get; set; }
    }
}
